# ============================================================
# config.py — Central configuration for AI Code Agent
# ============================================================

# ---- Ollama Settings ----------------------------------------
OLLAMA_BASE_URL = "http://localhost:2400"
OLLAMA_GENERATE_URL = f"{OLLAMA_BASE_URL}/api/generate"
OLLAMA_EMBED_URL = f"{OLLAMA_BASE_URL}/api/embeddings"
OLLAMA_CODING_MODEL = "qwen2.5-coder:14b"
OLLAMA_EMBED_MODEL = "nomic-embed-text"

# ---- ChromaDB Settings --------------------------------------
CHROMA_HOST = "localhost"
CHROMA_PORT = 8000
CHROMA_JAVA_COLLECTION = "java_codebase"
CHROMA_ANGULAR_COLLECTION = "angular_codebase"

# ---- Repository Paths ---------------------------------------
JAVA_REPO_ROOT = r"C:\projects\java-repo"        # <-- Update this
ANGULAR_REPO_ROOT = r"C:\projects\angular-repo"  # <-- Update this

# ---- Build Settings -----------------------------------------
MAVEN_EXECUTABLE = "mvn"                          # Ensure mvn is in PATH
ANGULAR_EXECUTABLE = "ng"                         # Ensure ng is in PATH
JAVA_BUILD_COMMAND = f"{MAVEN_EXECUTABLE} compile"
ANGULAR_BUILD_COMMAND = f"{ANGULAR_EXECUTABLE} build"

# ---- Agent Settings -----------------------------------------
MAX_CORRECTION_LOOPS = 5       # Max self-correction iterations per file
RAG_TOP_K = 5                  # Number of related files to fetch from ChromaDB
MAX_CHUNK_CHARS = 6000         # Max characters per code chunk sent to LLM

# ---- Logging ------------------------------------------------
LOG_FILE = r"C:\ai-agent\logs\agent_run.log"

# ---- File Extensions to Index -------------------------------
JAVA_EXTENSIONS = [".java"]
ANGULAR_EXTENSIONS = [".ts", ".html", ".scss", ".css"]

# ---- Folders to Exclude from Indexing ----------------------
EXCLUDE_DIRS = [
    "node_modules", ".git", "target", "dist",
    ".angular", "__pycache__", ".idea", ".vscode"
]
