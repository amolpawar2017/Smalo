# ============================================================
# indexer.py — Full repo indexer for Java + Angular codebase
# Chunks files, embeds via Ollama, stores in ChromaDB
# ============================================================

import os
import sys
import json
import requests
import chromadb
from chromadb.config import Settings
from datetime import datetime
from config import (
    OLLAMA_EMBED_URL, OLLAMA_EMBED_MODEL,
    CHROMA_HOST, CHROMA_PORT,
    CHROMA_JAVA_COLLECTION, CHROMA_ANGULAR_COLLECTION,
    JAVA_REPO_ROOT, ANGULAR_REPO_ROOT,
    JAVA_EXTENSIONS, ANGULAR_EXTENSIONS,
    EXCLUDE_DIRS, MAX_CHUNK_CHARS, LOG_FILE
)

# ---- Logging ------------------------------------------------
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---- ChromaDB Client ----------------------------------------
def get_chroma_client():
    client = chromadb.HttpClient(host=CHROMA_HOST, port=CHROMA_PORT)
    log(f"Connected to ChromaDB at {CHROMA_HOST}:{CHROMA_PORT}")
    return client

# ---- Ollama Embedding ---------------------------------------
def get_embedding(text: str) -> list:
    """Get embedding vector from Ollama nomic-embed-text model."""
    # Truncate if too long to avoid token limit issues
    truncated = text[:MAX_CHUNK_CHARS]
    payload = {
        "model": OLLAMA_EMBED_MODEL,
        "prompt": truncated
    }
    try:
        response = requests.post(OLLAMA_EMBED_URL, json=payload, timeout=60)
        response.raise_for_status()
        return response.json()["embedding"]
    except Exception as e:
        log(f"ERROR getting embedding: {e}")
        return None

# ---- File Crawler -------------------------------------------
def should_exclude(path: str) -> bool:
    """Check if a path contains any excluded directory."""
    parts = path.replace("\\", "/").split("/")
    return any(excl in parts for excl in EXCLUDE_DIRS)

def crawl_files(root_path: str, extensions: list) -> list:
    """Recursively find all files with given extensions."""
    found = []
    for dirpath, dirnames, filenames in os.walk(root_path):
        # Skip excluded directories in-place (prevents os.walk from descending)
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        if should_exclude(dirpath):
            continue
        for filename in filenames:
            if any(filename.endswith(ext) for ext in extensions):
                full_path = os.path.join(dirpath, filename)
                found.append(full_path)
    log(f"Found {len(found)} files in {root_path}")
    return found

# ---- Chunk File Content -------------------------------------
def chunk_file(file_path: str, max_chars: int = MAX_CHUNK_CHARS) -> list:
    """
    Read file and split into chunks.
    For Java: splits on class/method boundaries where possible.
    For others: splits on character limit.
    """
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception as e:
        log(f"ERROR reading {file_path}: {e}")
        return []

    if not content.strip():
        return []

    # If file fits in one chunk, return as-is
    if len(content) <= max_chars:
        return [content]

    # Otherwise split into overlapping chunks (500 char overlap for context)
    chunks = []
    start = 0
    overlap = 500
    while start < len(content):
        end = start + max_chars
        chunk = content[start:end]
        chunks.append(chunk)
        start = end - overlap  # overlap to preserve context between chunks

    return chunks

# ---- Extract Metadata ---------------------------------------
def extract_metadata(file_path: str, repo_root: str, language: str) -> dict:
    """Extract metadata for a file to store alongside embedding."""
    rel_path = os.path.relpath(file_path, repo_root)
    filename = os.path.basename(file_path)
    ext = os.path.splitext(filename)[1]

    # Try to extract class/component name from filename
    name = os.path.splitext(filename)[0]

    return {
        "file_path": file_path.replace("\\", "/"),
        "relative_path": rel_path.replace("\\", "/"),
        "filename": filename,
        "name": name,
        "language": language,
        "extension": ext,
        "indexed_at": datetime.now().isoformat()
    }

# ---- Index a Codebase ---------------------------------------
def index_codebase(
    collection_name: str,
    repo_root: str,
    extensions: list,
    language: str,
    chroma_client,
    force_reindex: bool = False
):
    log(f"\n{'='*60}")
    log(f"Indexing {language} codebase: {repo_root}")
    log(f"Collection: {collection_name}")
    log(f"{'='*60}")

    # Get or recreate collection
    if force_reindex:
        try:
            chroma_client.delete_collection(collection_name)
            log(f"Deleted existing collection: {collection_name}")
        except Exception:
            pass

    collection = chroma_client.get_or_create_collection(
        name=collection_name,
        metadata={"language": language, "repo_root": repo_root}
    )

    # Get existing IDs to skip already-indexed files
    existing = collection.get(include=[])
    existing_ids = set(existing["ids"]) if existing["ids"] else set()
    log(f"Already indexed: {len(existing_ids)} chunks")

    # Crawl files
    files = crawl_files(repo_root, extensions)

    total_chunks = 0
    skipped = 0
    errors = 0

    for file_path in files:
        chunks = chunk_file(file_path)
        if not chunks:
            continue

        metadata = extract_metadata(file_path, repo_root, language)

        for i, chunk in enumerate(chunks):
            chunk_id = f"{metadata['relative_path']}::chunk_{i}"

            # Skip if already indexed
            if chunk_id in existing_ids:
                skipped += 1
                continue

            # Get embedding from Ollama
            embedding = get_embedding(chunk)
            if embedding is None:
                errors += 1
                continue

            # Store in ChromaDB
            chunk_metadata = {**metadata, "chunk_index": i, "total_chunks": len(chunks)}

            try:
                collection.add(
                    ids=[chunk_id],
                    embeddings=[embedding],
                    documents=[chunk],
                    metadatas=[chunk_metadata]
                )
                total_chunks += 1

                if total_chunks % 10 == 0:
                    log(f"  Indexed {total_chunks} chunks so far...")

            except Exception as e:
                log(f"ERROR storing chunk {chunk_id}: {e}")
                errors += 1

    log(f"\n✅ {language} indexing complete!")
    log(f"   New chunks indexed : {total_chunks}")
    log(f"   Skipped (existing) : {skipped}")
    log(f"   Errors             : {errors}")
    log(f"   Total in collection: {collection.count()}")

    return total_chunks

# ---- Main ---------------------------------------------------
def main():
    import argparse
    parser = argparse.ArgumentParser(description="Index Java and Angular codebases into ChromaDB")
    parser.add_argument("--force", action="store_true", help="Force reindex (clears existing data)")
    parser.add_argument("--java-only", action="store_true", help="Index only Java codebase")
    parser.add_argument("--angular-only", action="store_true", help="Index only Angular codebase")
    args = parser.parse_args()

    log("Starting codebase indexing...")
    log(f"Force reindex: {args.force}")

    # Validate paths
    if not args.angular_only and not os.path.exists(JAVA_REPO_ROOT):
        log(f"ERROR: Java repo path not found: {JAVA_REPO_ROOT}")
        log("Please update JAVA_REPO_ROOT in config.py")
        sys.exit(1)

    if not args.java_only and not os.path.exists(ANGULAR_REPO_ROOT):
        log(f"ERROR: Angular repo path not found: {ANGULAR_REPO_ROOT}")
        log("Please update ANGULAR_REPO_ROOT in config.py")
        sys.exit(1)

    # Connect to ChromaDB
    try:
        client = get_chroma_client()
    except Exception as e:
        log(f"ERROR connecting to ChromaDB: {e}")
        log("Make sure ChromaDB container is running: podman start chromadb")
        sys.exit(1)

    start_time = datetime.now()

    # Index Java
    if not args.angular_only:
        index_codebase(
            collection_name=CHROMA_JAVA_COLLECTION,
            repo_root=JAVA_REPO_ROOT,
            extensions=JAVA_EXTENSIONS,
            language="java",
            chroma_client=client,
            force_reindex=args.force
        )

    # Index Angular
    if not args.java_only:
        index_codebase(
            collection_name=CHROMA_ANGULAR_COLLECTION,
            repo_root=ANGULAR_REPO_ROOT,
            extensions=ANGULAR_EXTENSIONS,
            language="angular",
            chroma_client=client,
            force_reindex=args.force
        )

    elapsed = datetime.now() - start_time
    log(f"\n🎉 All indexing complete in {elapsed}")
    log("You can now run agent.py to process files.")

if __name__ == "__main__":
    main()
