# ============================================================
# agent.py — Autonomous AI Code Agent with Reasoning Output
# Shows action plan and waits for user confirmation before
# executing any file changes.
# ============================================================

import os
import sys
import json
import shutil
import argparse
import requests
import chromadb
from datetime import datetime
from config import (
    OLLAMA_GENERATE_URL, OLLAMA_CODING_MODEL,
    OLLAMA_EMBED_URL, OLLAMA_EMBED_MODEL,
    CHROMA_HOST, CHROMA_PORT,
    CHROMA_TENANT, CHROMA_DATABASE,
    CHROMA_JAVA_COLLECTION, CHROMA_ANGULAR_COLLECTION,
    MAX_CORRECTION_LOOPS, RAG_TOP_K,
    MAX_CHUNK_CHARS, LOG_FILE,
    JAVA_REPO_ROOT, ANGULAR_REPO_ROOT
)
from build_validator import validate_file, format_errors_for_llm

# ---- Logging ------------------------------------------------
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def log_thinking(thinking: str):
    """Print model reasoning in a visually distinct cyan block."""
    if not thinking or not thinking.strip():
        return
    border = "─" * 60
    print(f"\n\033[36m{border}")
    print(f"  🧠 MODEL REASONING")
    print(f"{border}\033[0m")
    for line in thinking.strip().splitlines():
        print(f"\033[36m  {line}\033[0m")
    print(f"\033[36m{border}\033[0m\n")

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n{'─'*60}\n  MODEL REASONING\n{'─'*60}\n")
        f.write(thinking.strip() + "\n")
        f.write(f"{'─'*60}\n\n")

def print_plan(plan: dict):
    """Print the action plan in a clear, readable format for user review."""
    border = "═" * 60
    thin  = "─" * 60

    print(f"\n\033[33m{border}")
    print(f"  📋 ACTION PLAN")
    print(f"{border}\033[0m")
    print(f"\033[33m  Summary: {plan.get('summary', 'N/A')}\033[0m")
    print(f"\033[33m{thin}\033[0m")

    modify_list = plan.get("modify", [])
    create_list = plan.get("create", [])

    if modify_list:
        print(f"\n\033[33m  ✏️  FILES TO MODIFY ({len(modify_list)}):\033[0m")
        for i, item in enumerate(modify_list, 1):
            print(f"\033[33m  {i}. {item['file_path']}\033[0m")
            print(f"\033[33m     Reason  : {item['reason']}\033[0m")
            print(f"\033[33m     Changes : {item['changes']}\033[0m")

    if create_list:
        print(f"\n\033[33m  ➕ FILES TO CREATE ({len(create_list)}):\033[0m")
        for i, item in enumerate(create_list, 1):
            print(f"\033[33m  {i}. {item['file_path']}\033[0m")
            print(f"\033[33m     Reason      : {item['reason']}\033[0m")
            print(f"\033[33m     Description : {item['description']}\033[0m")

    total = len(modify_list) + len(create_list)
    print(f"\n\033[33m{thin}")
    print(f"  Total changes: {total} file(s)")
    print(f"{border}\033[0m\n")

    # Also write plan to log
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n{'='*60}\nACTION PLAN\n{'='*60}\n")
        f.write(f"Summary: {plan.get('summary', 'N/A')}\n\n")
        for item in modify_list:
            f.write(f"[MODIFY] {item['file_path']}\n")
            f.write(f"  Reason : {item['reason']}\n")
            f.write(f"  Changes: {item['changes']}\n\n")
        for item in create_list:
            f.write(f"[CREATE] {item['file_path']}\n")
            f.write(f"  Reason : {item['reason']}\n")
            f.write(f"  Desc   : {item['description']}\n\n")
        f.write(f"{'='*60}\n")

def confirm_plan(plan: dict) -> str:
    """
    Show plan and ask user to confirm, modify or cancel.
    Returns: 'proceed' | 'replan' | 'cancel'
    """
    print_plan(plan)

    print("\033[32m" + "─" * 60)
    print("  What would you like to do?")
    print("─" * 60 + "\033[0m")
    print("  \033[32m[Y]\033[0m Proceed with implementation")
    print("  \033[32m[R]\033[0m Replan with additional instructions")
    print("  \033[32m[N]\033[0m Cancel")
    print("\033[32m" + "─" * 60 + "\033[0m")

    while True:
        choice = input("\n  Your choice (Y/R/N): ").strip().upper()
        if choice in ["Y", "YES"]:
            return "proceed"
        elif choice in ["R", "REPLAN"]:
            return "replan"
        elif choice in ["N", "NO", "CANCEL"]:
            return "cancel"
        else:
            print("  Please enter Y, R, or N")

# ---- File Operations ----------------------------------------
def read_file(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write_file(path: str, content: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def backup_file(path: str):
    shutil.copy2(path, path + ".bak")
    log(f"Backup: {path}.bak")

def restore_backup(path: str):
    if os.path.exists(path + ".bak"):
        shutil.copy2(path + ".bak", path)
        log(f"Restored: {path}")

def cleanup_backup(path: str):
    if os.path.exists(path + ".bak"):
        os.remove(path + ".bak")

def delete_file(path: str):
    if os.path.exists(path):
        os.remove(path)
        log(f"Deleted failed new file: {path}")

# ---- Language Detection -------------------------------------
def detect_language(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".java":
        return "java"
    elif ext in [".ts", ".html", ".scss", ".css"]:
        return "angular"
    return "unknown"

def language_hint(file_path: str) -> str:
    lang = detect_language(file_path)
    return "Java Spring Boot" if lang == "java" else "Angular TypeScript" if lang == "angular" else "code"

def infer_java_package(file_path: str) -> str:
    try:
        normalized = file_path.replace("\\", "/")
        idx = normalized.find("/java/")
        if idx == -1:
            return ""
        rel = normalized[idx + 6:]
        return ".".join(rel.split("/")[:-1])
    except Exception:
        return ""

# ---- ChromaDB -----------------------------------------------
def get_chroma_client():
    return chromadb.HttpClient(
        host=CHROMA_HOST, port=CHROMA_PORT,
        tenant=CHROMA_TENANT, database=CHROMA_DATABASE
    )

def get_embedding(text: str) -> list:
    try:
        response = requests.post(
            OLLAMA_EMBED_URL,
            json={"model": OLLAMA_EMBED_MODEL, "prompt": text[:MAX_CHUNK_CHARS]},
            timeout=120
        )
        response.raise_for_status()
        return response.json()["embedding"]
    except Exception as e:
        log(f"WARNING: Embedding failed: {e}")
        return None

def retrieve_context(query: str, language: str, exclude_file: str = None) -> list:
    log(f"RAG query: {query[:80]}...")
    try:
        client = get_chroma_client()
        collection_name = CHROMA_JAVA_COLLECTION if language == "java" else CHROMA_ANGULAR_COLLECTION
        collection = client.get_collection(collection_name)

        embedding = get_embedding(query)
        results = collection.query(
            query_embeddings=[embedding] if embedding else None,
            query_texts=None if embedding else [query],
            n_results=RAG_TOP_K,
            include=["documents", "metadatas"]
        )

        context_files = []
        seen = set()
        for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
            fp = meta.get("file_path", "")
            if exclude_file and os.path.basename(fp) == os.path.basename(exclude_file):
                continue
            if fp in seen:
                continue
            seen.add(fp)
            context_files.append({
                "file_path": fp,
                "relative_path": meta.get("relative_path", fp),
                "content": doc
            })

        log(f"  Retrieved {len(context_files)} context files")
        return context_files
    except Exception as e:
        log(f"WARNING: RAG failed: {e}")
        return []

def format_context(context_files: list) -> str:
    return "\n\n".join(
        f"// File: {cf['relative_path']}\n{cf['content']}"
        for cf in context_files
    )

# ---- Ollama -------------------------------------------------
def call_ollama(prompt: str, temperature: float = 0.1, label: str = "") -> tuple:
    """
    Returns: (thinking: str, response: str)
    Tries native Ollama think param first, falls back to <thinking> tag parsing.
    """
    if label:
        log(f"🤖 Calling LLM: {label}")

    payload = {
        "model": OLLAMA_CODING_MODEL,
        "prompt": prompt,
        "stream": False,
        "think": True,
        "options": {"temperature": temperature, "num_predict": 8192}
    }

    try:
        response = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=300)
        response.raise_for_status()
        data = response.json()

        # Strategy 1: Native Ollama thinking field
        native_thinking = data.get("thinking", "").strip()
        raw_response = data.get("response", "").strip()
        if native_thinking:
            log_thinking(native_thinking)
            return native_thinking, raw_response

        # Strategy 2: Parse <thinking> tags from response
        if "<thinking>" in raw_response and "</thinking>" in raw_response:
            start = raw_response.find("<thinking>") + len("<thinking>")
            end = raw_response.find("</thinking>")
            thinking_block = raw_response[start:end].strip()
            actual_response = raw_response[end + len("</thinking>"):].strip()
            log_thinking(thinking_block)
            return thinking_block, actual_response

        return "", raw_response

    except requests.exceptions.Timeout:
        log("ERROR: Ollama timed out")
        return "", None
    except Exception as e:
        log(f"ERROR: Ollama failed: {e}")
        return "", None

def clean_code(response: str) -> str:
    if not response:
        return response
    response = response.strip()
    if response.startswith("```"):
        lines = response.split("\n")[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        response = "\n".join(lines)
    return response.strip()

def clean_json(response: str) -> str:
    if not response:
        return response
    response = response.strip()
    if response.startswith("```"):
        lines = response.split("\n")[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        response = "\n".join(lines)
    return response.strip()

# ============================================================
# PHASE 1 — PLANNING
# ============================================================

PLAN_PROMPT = """You are an expert software architect reviewing a codebase.

INSTRUCTION:
{instruction}

{refinement}

EXISTING CODEBASE CONTEXT:
{context}

JAVA REPO ROOT: {java_root}
ANGULAR REPO ROOT: {angular_root}

<thinking>
Think step by step:
1. What is the instruction asking for?
2. Which existing files are affected and why?
3. What new files need to be created?
4. What is the correct order of changes?
5. Any risks or dependencies to highlight?
</thinking>

After your thinking, respond with ONLY this JSON:
{{
  "summary": "brief description of what will be done",
  "modify": [
    {{
      "file_path": "absolute file path",
      "reason": "why this file needs to change",
      "changes": "specific changes to make"
    }}
  ],
  "create": [
    {{
      "file_path": "absolute file path",
      "reason": "why this file is needed",
      "description": "what this file should contain"
    }}
  ]
}}

RULES:
- Use absolute paths based on repo roots
- Only include files that genuinely need changes
- Empty arrays [] if nothing in that category"""


def plan_changes(instruction: str, refinement: str = "") -> dict:
    log("\n📋 PHASE 1: Planning changes...")

    java_context  = retrieve_context(instruction, "java")
    angular_context = retrieve_context(instruction, "angular")
    all_context   = format_context(java_context + angular_context)

    refinement_section = f"\nADDITIONAL INSTRUCTIONS FROM USER:\n{refinement}\n" if refinement else ""

    prompt = PLAN_PROMPT.format(
        instruction=instruction,
        refinement=refinement_section,
        context=all_context or "No existing context found.",
        java_root=JAVA_REPO_ROOT,
        angular_root=ANGULAR_REPO_ROOT
    )

    _, response = call_ollama(prompt, temperature=0.1, label="Planning changes")
    if not response:
        log("ERROR: No planning response")
        return None

    try:
        plan = json.loads(clean_json(response))
        return plan
    except json.JSONDecodeError as e:
        log(f"ERROR: Could not parse plan JSON: {e}")
        log(f"Raw response:\n{response[:500]}")
        return None


# ============================================================
# PHASE 2+3 — GENERATE + VALIDATE + SELF-CORRECT
# ============================================================

def build_modify_prompt(instruction, file_path, code, context, specific_changes):
    return f"""You are an expert {language_hint(file_path)} developer.

<thinking>
Think before writing:
1. What does the existing code currently do?
2. What specific changes are needed?
3. What imports might be required?
4. How to avoid breaking existing functionality?
</thinking>

After your thinking, return ONLY the complete updated file content.

INSTRUCTION: {instruction}
SPECIFIC CHANGES: {specific_changes}

RELATED CONTEXT:
{context}

FILE TO MODIFY: {os.path.basename(file_path)}
```
{code}
```

RULES: Return ONLY complete file. No markdown. No explanations."""


def build_create_prompt(instruction, file_path, context, description):
    pkg = infer_java_package(file_path) if detect_language(file_path) == "java" else ""
    return f"""You are an expert {language_hint(file_path)} developer.

<thinking>
Think before writing:
1. What is the purpose of this new file?
2. What imports are needed based on the context?
3. What naming conventions does this codebase use?
4. How does it integrate with existing code?
</thinking>

After your thinking, return ONLY the complete new file content.

INSTRUCTION: {instruction}
FILE: {os.path.basename(file_path)}
{"Package: " + pkg if pkg else ""}
DESCRIPTION: {description}

RELATED CONTEXT:
{context}

RULES: Return ONLY complete file. No markdown. No explanations. Must compile."""


def build_correction_prompt(instruction, file_path, code, errors, attempt):
    return f"""You are an expert developer fixing compilation errors.

<thinking>
Analyse each error carefully:
1. What is causing each error?
2. Missing imports? Type mismatches? Wrong method signatures?
3. What is the minimal fix?
</thinking>

After your thinking, return ONLY the complete corrected file.

INSTRUCTION: {instruction}
FILE: {os.path.basename(file_path)}

CURRENT CODE:
```
{code}
```

ERRORS (attempt {attempt}/{MAX_CORRECTION_LOOPS}):
{errors}

RULES: Fix ALL errors. Return ONLY complete file. No markdown."""


def process_single_file(file_path, instruction, mode, specific_info) -> bool:
    log(f"\n{'─'*60}")
    log(f"{'✏️  MODIFYING' if mode == 'modify' else '➕ CREATING'}: {file_path}")
    log(f"{'─'*60}")

    language = detect_language(file_path)
    is_new = mode == "create"

    if not is_new and os.path.exists(file_path):
        backup_file(file_path)
        original_code = read_file(file_path)
    elif not is_new:
        log(f"ERROR: File not found: {file_path}")
        return False
    else:
        original_code = None

    context = format_context(retrieve_context(
        query=f"{instruction} {os.path.basename(file_path)}",
        language=language,
        exclude_file=file_path
    ))

    label = f"{'Creating' if is_new else 'Modifying'} {os.path.basename(file_path)}"
    prompt = (
        build_create_prompt(instruction, file_path, context, specific_info)
        if is_new else
        build_modify_prompt(instruction, file_path, original_code, context, specific_info)
    )

    _, response = call_ollama(prompt, label=label)
    if not response:
        log("ERROR: No LLM response")
        if not is_new:
            restore_backup(file_path)
        return False

    generated_code = clean_code(response)
    write_file(file_path, generated_code)
    log(f"Written: {len(generated_code)} chars")

    build_result = validate_file(file_path)
    if build_result.success:
        log("✅ Build passed!")
        if not is_new:
            cleanup_backup(file_path)
        return True

    log(f"Build failed — self-correcting...")
    current_code = generated_code

    for attempt in range(1, MAX_CORRECTION_LOOPS + 1):
        log(f"\n  Correction attempt {attempt}/{MAX_CORRECTION_LOOPS}")
        error_msg = format_errors_for_llm(build_result, file_path)

        _, corrected = call_ollama(
            build_correction_prompt(instruction, file_path, current_code, error_msg, attempt),
            label=f"Fixing {os.path.basename(file_path)} (attempt {attempt})"
        )
        if not corrected:
            continue

        current_code = clean_code(corrected)
        write_file(file_path, current_code)
        build_result = validate_file(file_path)

        if build_result.success:
            log(f"✅ Fixed after {attempt} correction(s)!")
            if not is_new:
                cleanup_backup(file_path)
            return True
        log("  Still failing...")

    log(f"❌ Failed after {MAX_CORRECTION_LOOPS} attempts")
    if is_new:
        delete_file(file_path)
    else:
        restore_backup(file_path)
    return False


def execute_plan(plan: dict, instruction: str) -> bool:
    """Execute a confirmed plan."""
    modify_list = plan.get("modify", [])
    create_list = plan.get("create", [])
    total = len(modify_list) + len(create_list)

    log(f"\n⚙️  PHASE 2: Executing plan ({total} file(s))...")
    results = []

    for item in modify_list:
        success = process_single_file(
            file_path=item["file_path"],
            instruction=instruction,
            mode="modify",
            specific_info=item.get("changes", item.get("reason", ""))
        )
        results.append({"file": item["file_path"], "mode": "modify", "success": success})

    for item in create_list:
        success = process_single_file(
            file_path=item["file_path"],
            instruction=instruction,
            mode="create",
            specific_info=item.get("description", item.get("reason", ""))
        )
        results.append({"file": item["file_path"], "mode": "create", "success": success})

    # Summary
    log(f"\n{'='*60}")
    log("EXECUTION SUMMARY")
    log(f"{'='*60}")
    success_count = sum(1 for r in results if r["success"])
    fail_count    = len(results) - success_count

    for r in results:
        icon  = "✅" if r["success"] else "❌"
        label = "MODIFIED" if r["mode"] == "modify" else "CREATED "
        log(f"{icon} [{label}] {r['file']}")

    log(f"\nTotal: {len(results)} | ✅ {success_count} succeeded | ❌ {fail_count} failed")
    return fail_count == 0


# ============================================================
# MAIN ORCHESTRATOR
# ============================================================

def run_agent(instruction: str) -> bool:
    log(f"\n{'='*60}")
    log(f"AUTONOMOUS AGENT STARTED")
    log(f"Instruction: {instruction}")
    log(f"{'='*60}")

    refinement = ""
    max_replan_attempts = 3

    for replan_attempt in range(max_replan_attempts):

        # Phase 1: Plan
        plan = plan_changes(instruction, refinement=refinement)
        if not plan:
            log("ERROR: Planning failed")
            return False

        total = len(plan.get("modify", [])) + len(plan.get("create", []))
        if total == 0:
            log("ℹ️  No file changes identified for this instruction")
            return True

        # Show plan and ask for confirmation
        decision = confirm_plan(plan)

        if decision == "proceed":
            log("✅ User confirmed plan — starting implementation...")
            return execute_plan(plan, instruction)

        elif decision == "replan":
            print()
            refinement = input("  Enter additional instructions for replanning: ").strip()
            log(f"Replanning with refinement: {refinement}")
            continue

        elif decision == "cancel":
            log("🚫 User cancelled — no files were changed")
            print("\n\033[31m  Operation cancelled. No files were modified.\033[0m\n")
            return False

    log("Max replan attempts reached")
    return False


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Autonomous AI Code Agent with Plan Confirmation")

    # Requirement sources — at least one must be provided
    req_group = parser.add_mutually_exclusive_group(required=True)
    req_group.add_argument(
        "--instruction",
        help="Plain text instruction describing what to implement or change"
    )
    req_group.add_argument(
        "--requirement-file",
        dest="requirement_file",
        help="Path to image (.png/.jpg) or Excel (.xlsx/.xls/.csv) file containing requirements"
    )

    # Optional extra context when using a requirement file
    parser.add_argument(
        "--extra",
        default="",
        help="Optional extra instruction to combine with requirement file content"
    )

    args = parser.parse_args()

    # ---- Resolve instruction --------------------------------
    if args.requirement_file:
        # Import here so it's only needed when used
        from requirement_reader import read_requirement, check_dependencies
        check_dependencies()

        try:
            instruction = read_requirement(
                file_path=args.requirement_file,
                extra_instruction=args.extra
            )
        except (FileNotFoundError, ValueError, RuntimeError) as e:
            log(f"ERROR reading requirement file: {e}")
            sys.exit(1)
    else:
        instruction = args.instruction

    # ---- Run agent ------------------------------------------
    success = run_agent(instruction=instruction)

    if success:
        log("\n🎉 Agent completed successfully!")
        sys.exit(0)
    else:
        log("\n💥 Agent finished — see log for details")
        sys.exit(1)
