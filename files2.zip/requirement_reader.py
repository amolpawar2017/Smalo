# ============================================================
# requirement_reader.py — Extract requirements from image or Excel
# Supports: .png, .jpg, .jpeg, .bmp, .gif, .xlsx, .xls, .csv
# ============================================================

import os
import sys
import base64
import requests
from datetime import datetime
from config import (
    OLLAMA_GENERATE_URL, OLLAMA_CODING_MODEL,
    LOG_FILE
)

# ---- Logging ------------------------------------------------
def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def log_thinking(thinking: str):
    if not thinking or not thinking.strip():
        return
    border = "─" * 60
    print(f"\n\033[36m{border}")
    print(f"  🧠 MODEL REASONING")
    print(f"{border}\033[0m")
    for line in thinking.strip().splitlines():
        print(f"\033[36m  {line}\033[0m")
    print(f"\033[36m{border}\033[0m\n")

# ---- File Type Detection ------------------------------------
IMAGE_EXTENSIONS  = [".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp"]
EXCEL_EXTENSIONS  = [".xlsx", ".xls"]
CSV_EXTENSIONS    = [".csv"]

def get_file_type(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext in IMAGE_EXTENSIONS:
        return "image"
    elif ext in EXCEL_EXTENSIONS:
        return "excel"
    elif ext in CSV_EXTENSIONS:
        return "csv"
    else:
        return "unknown"

def get_image_media_type(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    mapping = {
        ".png":  "image/png",
        ".jpg":  "image/jpeg",
        ".jpeg": "image/jpeg",
        ".bmp":  "image/bmp",
        ".gif":  "image/gif",
        ".webp": "image/webp"
    }
    return mapping.get(ext, "image/png")

# ============================================================
# IMAGE REQUIREMENT EXTRACTION
# Uses Ollama vision model to read image and extract requirement
# ============================================================

def encode_image_base64(file_path: str) -> str:
    with open(file_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

def extract_from_image(file_path: str) -> str:
    """
    Send image to Ollama vision model and extract requirement text.
    Uses llama3.2-vision or qwen2.5-coder with vision if available.
    """
    log(f"📸 Reading requirement from image: {file_path}")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Image file not found: {file_path}")

    image_data = encode_image_base64(file_path)
    media_type = get_image_media_type(file_path)

    prompt = """You are a software requirements analyst.
Carefully examine this image which contains software requirements, user stories, 
wireframes, diagrams, or feature specifications.

<thinking>
1. What type of content is in this image? (text, diagram, wireframe, table, screenshot?)
2. What are the main requirements or features described?
3. Are there any technical details like APIs, data models, or UI components?
4. What is the expected behavior or functionality?
</thinking>

After your analysis, extract and formulate a clear, detailed software requirement 
in plain English. Include:
- What feature or functionality needs to be implemented
- Any specific technical requirements (APIs, data formats, validations)
- Expected inputs and outputs
- Any constraints or business rules visible

Format as a clear requirement statement that a developer can act on directly."""

    payload = {
        "model": OLLAMA_CODING_MODEL,
        "prompt": prompt,
        "stream": False,
        "think": True,
        "images": [image_data],
        "options": {"temperature": 0.1, "num_predict": 2048}
    }

    try:
        log("Sending image to Ollama for analysis...")
        response = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=300)
        response.raise_for_status()
        data = response.json()

        thinking = data.get("thinking", "").strip()
        raw_response = data.get("response", "").strip()

        # Fallback: parse <thinking> tags
        if not thinking and "<thinking>" in raw_response:
            start = raw_response.find("<thinking>") + len("<thinking>")
            end   = raw_response.find("</thinking>")
            thinking     = raw_response[start:end].strip()
            raw_response = raw_response[end + len("</thinking>"):].strip()

        if thinking:
            log_thinking(thinking)

        if not raw_response:
            raise ValueError("Empty response from vision model")

        log(f"✅ Image requirement extracted ({len(raw_response)} chars)")
        return raw_response

    except requests.exceptions.Timeout:
        raise TimeoutError("Vision model timed out — image may be too complex")
    except Exception as e:
        raise RuntimeError(f"Image extraction failed: {e}")


# ============================================================
# EXCEL REQUIREMENT EXTRACTION
# Reads sheets/rows and uses LLM to formulate requirement
# ============================================================

def read_excel_content(file_path: str) -> str:
    """Read Excel file and return structured text representation."""
    try:
        import openpyxl
    except ImportError:
        raise ImportError("openpyxl not installed. Run: pip install openpyxl")

    log(f"📊 Reading Excel file: {file_path}")
    wb = openpyxl.load_workbook(file_path, data_only=True)

    content_parts = []

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows = []

        for row in ws.iter_rows(values_only=True):
            # Skip completely empty rows
            if all(cell is None for cell in row):
                continue
            row_values = [str(cell) if cell is not None else "" for cell in row]
            rows.append(" | ".join(row_values))

        if rows:
            content_parts.append(f"=== Sheet: {sheet_name} ===\n" + "\n".join(rows))

    if not content_parts:
        raise ValueError("Excel file appears to be empty")

    return "\n\n".join(content_parts)


def read_csv_content(file_path: str) -> str:
    """Read CSV file and return text representation."""
    import csv
    log(f"📄 Reading CSV file: {file_path}")

    rows = []
    with open(file_path, "r", encoding="utf-8-sig", errors="ignore") as f:
        reader = csv.reader(f)
        for row in reader:
            if any(cell.strip() for cell in row):
                rows.append(" | ".join(row))

    if not rows:
        raise ValueError("CSV file appears to be empty")

    return "\n".join(rows)


def extract_from_excel(file_path: str) -> str:
    """
    Read Excel/CSV and use LLM to formulate a clear software requirement.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext in EXCEL_EXTENSIONS:
        raw_content = read_excel_content(file_path)
    elif ext in CSV_EXTENSIONS:
        raw_content = read_csv_content(file_path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    log(f"Excel/CSV content read: {len(raw_content)} chars")

    # Truncate if too large to fit in context
    max_chars = 8000
    if len(raw_content) > max_chars:
        raw_content = raw_content[:max_chars] + "\n... [truncated]"
        log(f"Content truncated to {max_chars} chars for LLM context")

    prompt = f"""You are a software requirements analyst.
The following data is from a spreadsheet containing software requirements, 
user stories, feature specifications, or technical specifications.

<thinking>
1. What type of requirements are in this spreadsheet? (user stories, feature list, API specs, data model?)
2. What are the main features or functionalities described?
3. Are there priorities, acceptance criteria, or technical details?
4. What is the overall scope of work?
</thinking>

After your analysis, extract and formulate a clear, actionable software requirement 
in plain English. Include:
- What needs to be implemented
- Specific technical requirements from the data
- Expected inputs, outputs, validations
- Any priorities or constraints mentioned

SPREADSHEET CONTENT:
{raw_content}

Produce a single, comprehensive requirement statement a developer can act on directly."""

    log("Sending Excel content to LLM for analysis...")
    try:
        response = requests.post(
            OLLAMA_GENERATE_URL,
            json={
                "model": OLLAMA_CODING_MODEL,
                "prompt": prompt,
                "stream": False,
                "think": True,
                "options": {"temperature": 0.1, "num_predict": 2048}
            },
            timeout=300
        )
        response.raise_for_status()
        data = response.json()

        thinking = data.get("thinking", "").strip()
        raw_response = data.get("response", "").strip()

        if not thinking and "<thinking>" in raw_response:
            start = raw_response.find("<thinking>") + len("<thinking>")
            end   = raw_response.find("</thinking>")
            thinking     = raw_response[start:end].strip()
            raw_response = raw_response[end + len("</thinking>"):].strip()

        if thinking:
            log_thinking(thinking)

        if not raw_response:
            raise ValueError("Empty response from LLM")

        log(f"✅ Excel requirement extracted ({len(raw_response)} chars)")
        return raw_response

    except Exception as e:
        raise RuntimeError(f"Excel extraction failed: {e}")


# ============================================================
# MAIN ENTRY — read_requirement()
# ============================================================

def read_requirement(file_path: str, extra_instruction: str = "") -> str:
    """
    Main function. Detects file type and extracts requirement.

    Args:
        file_path:         Path to image or Excel file
        extra_instruction: Optional extra context from user via --instruction

    Returns:
        Full formulated requirement string ready for the agent planner
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Requirement file not found: {file_path}")

    file_type = get_file_type(file_path)

    if file_type == "unknown":
        raise ValueError(
            f"Unsupported file type: {os.path.splitext(file_path)[1]}\n"
            f"Supported: {IMAGE_EXTENSIONS + EXCEL_EXTENSIONS + CSV_EXTENSIONS}"
        )

    log(f"\n{'='*60}")
    log(f"READING REQUIREMENT FROM {file_type.upper()}: {file_path}")
    log(f"{'='*60}")

    if file_type == "image":
        extracted = extract_from_image(file_path)
    else:
        extracted = extract_from_excel(file_path)

    # Combine extracted requirement with any extra instruction from user
    if extra_instruction and extra_instruction.strip():
        full_requirement = (
            f"{extracted}\n\n"
            f"ADDITIONAL CONTEXT FROM USER:\n{extra_instruction.strip()}"
        )
    else:
        full_requirement = extracted

    # Show extracted requirement to user
    border = "═" * 60
    print(f"\n\033[35m{border}")
    print(f"  📝 EXTRACTED REQUIREMENT")
    print(f"{border}\033[0m")
    for line in full_requirement.splitlines():
        print(f"\033[35m  {line}\033[0m")
    print(f"\033[35m{border}\033[0m\n")

    # Ask user to confirm or edit the extracted requirement
    print("\033[32m  Is this requirement correct?\033[0m")
    print("  \033[32m[Y]\033[0m Proceed with this requirement")
    print("  \033[32m[E]\033[0m Edit / add to the requirement")
    print("  \033[32m[N]\033[0m Cancel")

    while True:
        choice = input("\n  Your choice (Y/E/N): ").strip().upper()
        if choice in ["Y", "YES"]:
            log(f"Requirement confirmed by user")
            return full_requirement
        elif choice in ["E", "EDIT"]:
            print("\n  Enter your edited/additional requirement text:")
            edited = input("  > ").strip()
            if edited:
                full_requirement = edited
                log(f"Requirement edited by user")
                return full_requirement
        elif choice in ["N", "NO"]:
            log("Requirement reading cancelled by user")
            sys.exit(0)
        else:
            print("  Please enter Y, E, or N")


# ============================================================
# INSTALL HELPER
# ============================================================

def check_dependencies():
    """Check and prompt to install required packages."""
    missing = []
    try:
        import openpyxl
    except ImportError:
        missing.append("openpyxl")

    if missing:
        print(f"\n⚠️  Missing dependencies: {', '.join(missing)}")
        print(f"Run: pip install {' '.join(missing)}")
        sys.exit(1)


if __name__ == "__main__":
    # Quick test
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", required=True, help="Path to image or Excel file")
    parser.add_argument("--instruction", default="", help="Extra context")
    args = parser.parse_args()

    result = read_requirement(args.file, args.instruction)
    print(f"\nFinal requirement:\n{result}")
