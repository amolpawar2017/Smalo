# ============================================================
# build_validator.py — Runs Maven/Angular build and captures errors
# ============================================================

import subprocess
import os
import re
from datetime import datetime
from config import (
    JAVA_REPO_ROOT, ANGULAR_REPO_ROOT,
    MAVEN_EXECUTABLE, ANGULAR_EXECUTABLE,
    LOG_FILE
)

# ---- Logging ------------------------------------------------
def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---- Build Result Model -------------------------------------
class BuildResult:
    def __init__(self, success: bool, errors: list, warnings: list, raw_output: str):
        self.success = success
        self.errors = errors
        self.warnings = warnings
        self.raw_output = raw_output

    def __str__(self):
        if self.success:
            return "✅ Build SUCCESS"
        return f"❌ Build FAILED with {len(self.errors)} error(s):\n" + "\n".join(self.errors)

# ---- Run Shell Command --------------------------------------
def run_command(command: str, cwd: str, timeout: int = 300) -> tuple:
    """Run a shell command and return (returncode, stdout, stderr)."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", f"Build timed out after {timeout} seconds"
    except Exception as e:
        return -1, "", str(e)

# ---- Parse Maven Errors -------------------------------------
def parse_maven_errors(stdout: str, stderr: str) -> tuple:
    """Extract error and warning lines from Maven output."""
    errors = []
    warnings = []
    combined = stdout + "\n" + stderr

    for line in combined.splitlines():
        stripped = line.strip()
        # Maven errors look like: [ERROR] /path/File.java:[10,5] error message
        if stripped.startswith("[ERROR]") and ".java" in stripped:
            errors.append(stripped)
        elif stripped.startswith("[ERROR]") and "ERROR" in stripped:
            errors.append(stripped)
        elif stripped.startswith("[WARNING]"):
            warnings.append(stripped)

    return errors, warnings

# ---- Parse Angular Errors -----------------------------------
def parse_angular_errors(stdout: str, stderr: str) -> tuple:
    """Extract error and warning lines from Angular build output."""
    errors = []
    warnings = []
    combined = stdout + "\n" + stderr

    for line in combined.splitlines():
        stripped = line.strip()
        # Angular errors look like: ERROR in src/app/...
        if stripped.startswith("ERROR in") or stripped.startswith("Error:"):
            errors.append(stripped)
        elif "TS" in stripped and "error TS" in stripped:
            # TypeScript errors: TS2345, TS2304 etc
            errors.append(stripped)
        elif stripped.startswith("Warning") or "warning" in stripped.lower():
            warnings.append(stripped)

    return errors, warnings

# ---- Detect Language from File Path -------------------------
def detect_language(file_path: str) -> str:
    """Detect if file is Java or Angular based on extension."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".java":
        return "java"
    elif ext in [".ts", ".html", ".scss", ".css"]:
        return "angular"
    return "unknown"

# ---- Run Maven Build ----------------------------------------
def run_maven_build(file_path: str = None) -> BuildResult:
    """Run Maven compile and return BuildResult."""
    log(f"Running Maven build in: {JAVA_REPO_ROOT}")

    command = f"{MAVEN_EXECUTABLE} compile -q"
    returncode, stdout, stderr = run_command(command, cwd=JAVA_REPO_ROOT)

    errors, warnings = parse_maven_errors(stdout, stderr)
    raw = stdout + stderr

    # If specific file provided, filter errors to that file only
    if file_path:
        filename = os.path.basename(file_path)
        errors = [e for e in errors if filename in e or not any(
            ext in e for ext in [".java"]
        )]

    success = returncode == 0 and len(errors) == 0

    result = BuildResult(
        success=success,
        errors=errors,
        warnings=warnings,
        raw_output=raw
    )

    log(str(result))
    if warnings:
        log(f"  Warnings: {len(warnings)}")

    return result

# ---- Run Angular Build --------------------------------------
def run_angular_build(file_path: str = None) -> BuildResult:
    """Run Angular build and return BuildResult."""
    log(f"Running Angular build in: {ANGULAR_REPO_ROOT}")

    # Use ng build with optimization off for faster feedback
    command = f"{ANGULAR_EXECUTABLE} build --configuration development"
    returncode, stdout, stderr = run_command(command, cwd=ANGULAR_REPO_ROOT)

    errors, warnings = parse_angular_errors(stdout, stderr)
    raw = stdout + stderr

    success = returncode == 0 and len(errors) == 0

    result = BuildResult(
        success=success,
        errors=errors,
        warnings=warnings,
        raw_output=raw
    )

    log(str(result))
    return result

# ---- Auto-detect and Run Build ------------------------------
def validate_file(file_path: str) -> BuildResult:
    """Auto-detect language and run appropriate build."""
    language = detect_language(file_path)

    if language == "java":
        return run_maven_build(file_path)
    elif language == "angular":
        return run_angular_build(file_path)
    else:
        log(f"WARNING: Unknown file type for {file_path}, skipping build")
        return BuildResult(
            success=True,
            errors=[],
            warnings=[f"Unknown file type, build skipped: {file_path}"],
            raw_output=""
        )

# ---- Format Errors for LLM ----------------------------------
def format_errors_for_llm(result: BuildResult, file_path: str) -> str:
    """Format build errors into a clear prompt section for the LLM."""
    if result.success:
        return ""

    lines = [
        f"The following compilation errors were found after modifying {os.path.basename(file_path)}:",
        ""
    ]
    for i, error in enumerate(result.errors, 1):
        lines.append(f"{i}. {error}")

    lines.append("")
    lines.append("Please fix all the above errors and return the complete corrected file.")
    return "\n".join(lines)
