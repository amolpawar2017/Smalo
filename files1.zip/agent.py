# ============================================================
# agent.py — Core AI Agent: RAG + LLM + Self-Correction Loop
# ============================================================

import os
import sys
import json
import shutil
import argparse
import requests
import chromadb
from datetime import datetime
from config import (
    OLLAMA_GENERATE_URL, OLLAMA_CODING_MODEL,
    OLLAMA_EMBED_URL, OLLAMA_EMBED_MODEL,
    CHROMA_HOST, CHROMA_PORT,
    CHROMA_TENANT, CHROMA_DATABASE,
    CHROMA_JAVA_COLLECTION, CHROMA_ANGULAR_COLLECTION,
    MAX_CORRECTION_LOOPS, RAG_TOP_K,
    MAX_CHUNK_CHARS, LOG_FILE
)
from build_validator import validate_file, format_errors_for_llm

# ---- Logging ------------------------------------------------
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---- File Operations ----------------------------------------
def read_file(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write_file(path: str, content: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def backup_file(path: str) -> str:
    """Create a backup before modifying."""
    backup_path = path + ".bak"
    shutil.copy2(path, backup_path)
    log(f"Backup created: {backup_path}")
    return backup_path

def restore_backup(path: str):
    """Restore original file from backup if all corrections fail."""
    backup_path = path + ".bak"
    if os.path.exists(backup_path):
        shutil.copy2(backup_path, path)
        log(f"⚠️ Restored original file from backup: {path}")

def cleanup_backup(path: str):
    """Remove backup after successful completion."""
    backup_path = path + ".bak"
    if os.path.exists(backup_path):
        os.remove(backup_path)

# ---- Detect Language ----------------------------------------
def detect_language(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".java":
        return "java"
    elif ext in [".ts", ".html", ".scss", ".css"]:
        return "angular"
    return "unknown"

# ---- ChromaDB Client ----------------------------------------
def get_chroma_client():
    return chromadb.HttpClient(
        host=CHROMA_HOST,
        port=CHROMA_PORT,
        tenant=CHROMA_TENANT,
        database=CHROMA_DATABASE
    )

# ---- RAG: Get Embedding -------------------------------------
def get_embedding(text: str) -> list:
    payload = {
        "model": OLLAMA_EMBED_MODEL,
        "prompt": text[:MAX_CHUNK_CHARS]
    }
    try:
        response = requests.post(OLLAMA_EMBED_URL, json=payload, timeout=120)
        response.raise_for_status()
        return response.json()["embedding"]
    except Exception as e:
        log(f"WARNING: Could not get embedding for RAG query: {e}")
        return None

# ---- RAG: Retrieve Related Context --------------------------
def retrieve_context(instruction: str, file_path: str, language: str) -> str:
    """
    Query ChromaDB to find related code files as context for the LLM.
    Returns formatted context string.
    """
    log(f"Retrieving RAG context for: {os.path.basename(file_path)}")

    try:
        client = get_chroma_client()
        collection_name = CHROMA_JAVA_COLLECTION if language == "java" else CHROMA_ANGULAR_COLLECTION
        collection = client.get_collection(collection_name)

        # Build query from instruction + filename
        query = f"{instruction} {os.path.basename(file_path)}"
        embedding = get_embedding(query)

        if embedding:
            results = collection.query(
                query_embeddings=[embedding],
                n_results=RAG_TOP_K,
                include=["documents", "metadatas", "distances"]
            )
        else:
            # Fallback to text query if embedding fails
            results = collection.query(
                query_texts=[query],
                n_results=RAG_TOP_K,
                include=["documents", "metadatas"]
            )

        # Format context - exclude the current file itself
        current_filename = os.path.basename(file_path)
        context_parts = []

        for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
            if meta["filename"] == current_filename:
                continue  # Skip current file, we already have it
            context_parts.append(
                f"// File: {meta['relative_path']}\n{doc}"
            )

        if context_parts:
            log(f"  Found {len(context_parts)} related files for context")
            return "\n\n".join(context_parts[:RAG_TOP_K])
        else:
            log("  No related context found")
            return ""

    except Exception as e:
        log(f"WARNING: RAG retrieval failed: {e} — proceeding without context")
        return ""

# ---- Ollama: Call LLM ---------------------------------------
def call_ollama(prompt: str) -> str:
    """Send prompt to Ollama and return generated code."""
    payload = {
        "model": OLLAMA_CODING_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.1,    # Low temp for deterministic code generation
            "num_predict": 4096    # Max tokens for response
        }
    }
    try:
        response = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=300)
        response.raise_for_status()
        return response.json()["response"]
    except requests.exceptions.Timeout:
        log("ERROR: Ollama request timed out")
        return None
    except Exception as e:
        log(f"ERROR calling Ollama: {e}")
        return None

# ---- Clean LLM Response -------------------------------------
def clean_response(response: str, language: str) -> str:
    """Strip markdown code fences if model adds them."""
    if not response:
        return response

    response = response.strip()

    # Remove opening code fence (```java, ```typescript, ```, etc.)
    if response.startswith("```"):
        lines = response.split("\n")
        # Remove first line (``` or ```java)
        lines = lines[1:]
        # Remove last line if it's closing ```
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        response = "\n".join(lines)

    return response.strip()

# ---- Build Prompt -------------------------------------------
def build_initial_prompt(instruction: str, filename: str, code: str, context: str) -> str:
    """Build the initial code modification prompt."""
    context_section = ""
    if context:
        context_section = f"""
RELATED CODEBASE CONTEXT (for reference only, do not modify these):
{context}

"""

    lang_hint = "Java Spring Boot" if filename.endswith(".java") else "Angular TypeScript"

    return f"""You are an expert {lang_hint} developer.
Your task is to modify the provided file based on the instruction.

INSTRUCTION:
{instruction}
{context_section}
TARGET FILE TO MODIFY: {filename}
```
{code}
```

RULES:
- Return ONLY the complete updated file content
- No explanations, no markdown, no code fences
- Preserve all existing functionality unless the instruction says otherwise
- Keep all existing imports unless they become unused
- Follow {lang_hint} best practices"""

def build_correction_prompt(
    instruction: str,
    filename: str,
    current_code: str,
    error_message: str,
    attempt: int
) -> str:
    """Build a self-correction prompt when build fails."""
    return f"""You are an expert developer fixing compilation errors.

ORIGINAL INSTRUCTION:
{instruction}

FILE: {filename}
CURRENT CODE (with errors):
```
{current_code}
```

COMPILATION ERRORS (attempt {attempt}/{MAX_CORRECTION_LOOPS}):
{error_message}

RULES:
- Fix ALL the compilation errors listed above
- Keep the original instruction implemented correctly
- Return ONLY the complete corrected file content
- No explanations, no markdown, no code fences"""

# ---- Main Agent Logic ---------------------------------------
def process_file(file_path: str, instruction: str) -> bool:
    """
    Main agent workflow:
    1. Read file
    2. RAG context retrieval
    3. LLM code generation
    4. Write file
    5. Compile validation
    6. Self-correction loop if errors
    Returns True if successful, False if failed.
    """
    log(f"\n{'='*60}")
    log(f"Processing: {file_path}")
    log(f"Instruction: {instruction}")
    log(f"{'='*60}")

    # Validate file exists
    if not os.path.exists(file_path):
        log(f"ERROR: File not found: {file_path}")
        return False

    language = detect_language(file_path)
    filename = os.path.basename(file_path)

    # Read original code
    original_code = read_file(file_path)
    log(f"File read: {len(original_code)} characters")

    # Create backup before any changes
    backup_file(file_path)

    # Step 1: RAG - get related context
    context = retrieve_context(instruction, file_path, language)

    # Step 2: Build initial prompt and call LLM
    log("Calling LLM for initial code generation...")
    prompt = build_initial_prompt(instruction, filename, original_code, context)
    response = call_ollama(prompt)

    if not response:
        log("ERROR: No response from LLM")
        restore_backup(file_path)
        return False

    updated_code = clean_response(response, language)

    # Step 3: Write updated code to file
    write_file(file_path, updated_code)
    log(f"File updated: {len(updated_code)} characters written")

    # Step 4: Validate build
    log("Running build validation...")
    build_result = validate_file(file_path)

    if build_result.success:
        log(f"✅ Build passed on first attempt!")
        cleanup_backup(file_path)
        return True

    # Step 5: Self-correction loop
    log(f"Build failed — starting self-correction loop (max {MAX_CORRECTION_LOOPS} attempts)")
    current_code = updated_code

    for attempt in range(1, MAX_CORRECTION_LOOPS + 1):
        log(f"\n--- Correction Attempt {attempt}/{MAX_CORRECTION_LOOPS} ---")

        error_message = format_errors_for_llm(build_result, file_path)
        log(f"Errors to fix:\n{error_message}")

        # Build correction prompt
        correction_prompt = build_correction_prompt(
            instruction=instruction,
            filename=filename,
            current_code=current_code,
            error_message=error_message,
            attempt=attempt
        )

        # Call LLM for correction
        log("Calling LLM for correction...")
        corrected_response = call_ollama(correction_prompt)

        if not corrected_response:
            log(f"ERROR: No response from LLM on attempt {attempt}")
            continue

        corrected_code = clean_response(corrected_response, language)

        # Write corrected code
        write_file(file_path, corrected_code)
        log(f"Corrected code written ({len(corrected_code)} chars)")

        # Validate again
        build_result = validate_file(file_path)

        if build_result.success:
            log(f"✅ Build passed after {attempt} correction(s)!")
            cleanup_backup(file_path)
            return True

        current_code = corrected_code
        log(f"Still failing after attempt {attempt}...")

    # All attempts exhausted
    log(f"\n❌ Could not fix errors after {MAX_CORRECTION_LOOPS} attempts")
    log(f"Restoring original file from backup...")
    restore_backup(file_path)
    log(f"Original file restored. Manual review required for: {file_path}")
    return False

# ---- Entry Point --------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI Code Agent with RAG + Self-Correction")
    parser.add_argument("--file", required=True, help="Full path to the code file to modify")
    parser.add_argument("--instruction", required=True, help="What changes to make to the file")
    args = parser.parse_args()

    success = process_file(
        file_path=args.file,
        instruction=args.instruction
    )

    if success:
        log("\n🎉 Agent completed successfully!")
        sys.exit(0)
    else:
        log("\n💥 Agent failed — original file preserved")
        sys.exit(1)
